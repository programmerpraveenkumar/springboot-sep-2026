package com.app1.app1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
